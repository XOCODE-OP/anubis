'use strict'

const fromString = require('uint8arrays/from-string')

exports.fixture = Object.freeze({
  cid: 'Qma4hjFTnCasJ8PVp3mZbZK5g2vGDT4LByLJ7m8ciyRFZP',
  data: fromString('Plz add me!\n')
})
