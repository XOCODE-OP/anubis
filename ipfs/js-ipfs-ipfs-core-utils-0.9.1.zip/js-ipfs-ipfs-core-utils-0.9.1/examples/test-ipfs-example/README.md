# test-ipfs-example

This module contains configuration for nightwatch.js and a basic test runner.

[Lerna](http://npmjs.com/package/lerna) should have symlinked this for you in the right place when you ran `npm i` in the root of the [IPFS repo](https://github.com/ipfs/js-ipfs).

If you've installed it, it's probably because you ran `npm i` in one of the [IPFS examples](https://github.com/ipfs/js-ipfs/tree/master/examples).
