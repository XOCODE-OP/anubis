# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.1.2](https://github.com/ipfs/js-ipfs/compare/example-browser-vue@0.1.1...example-browser-vue@0.1.2) (2020-04-08)

**Note:** Version bump only for package example-browser-vue





## 0.1.1 (2020-03-31)


### Features

* remove ky from http-client and utils ([#2810](https://github.com/ipfs/js-ipfs/issues/2810)) ([9bc9625](https://github.com/ipfs/js-ipfs/commit/9bc96252686d0bbbfdb2a3300bb17b80eafdaf00)), closes [#2801](https://github.com/ipfs/js-ipfs/issues/2801)
