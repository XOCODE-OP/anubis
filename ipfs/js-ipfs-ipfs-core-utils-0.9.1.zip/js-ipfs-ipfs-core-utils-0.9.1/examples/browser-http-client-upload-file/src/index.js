/* eslint-disable no-unused-vars */
'use strict'
const React = require('react')
const ReactDOM = require('react-dom')
const App = require('./App')

ReactDOM.render(<App />, document.getElementById('root'))
