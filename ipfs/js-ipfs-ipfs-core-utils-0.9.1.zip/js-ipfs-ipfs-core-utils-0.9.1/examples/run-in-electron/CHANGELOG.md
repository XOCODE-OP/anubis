# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.0.2](https://github.com/ipfs/js-ipfs/compare/example-js-ipfs-in-electron@0.0.1...example-js-ipfs-in-electron@0.0.2) (2020-04-08)

**Note:** Version bump only for package example-js-ipfs-in-electron





## 0.0.1 (2020-03-31)


### Bug Fixes

* upgrade electron examples ([#2104](https://github.com/ipfs/js-ipfs/issues/2104)) ([67e1b59](https://github.com/ipfs/js-ipfs/commit/67e1b5986c1feecc9ff160c6a6962038a727ef3e))


### Features

* get Ping to work properly ([27d5a57](https://github.com/ipfs/js-ipfs/commit/27d5a575c58a445bba4ba1f86d22ccc76623ef64))
