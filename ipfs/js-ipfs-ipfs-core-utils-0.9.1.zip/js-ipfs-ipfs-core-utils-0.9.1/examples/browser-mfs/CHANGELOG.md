# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.0.2](https://github.com/ipfs/js-ipfs/compare/example-browser-mfs@1.0.1...example-browser-mfs@1.0.2) (2020-04-08)

**Note:** Version bump only for package example-browser-mfs





## 1.0.1 (2020-03-31)


### Bug Fixes

* browser-mfs example ([#2089](https://github.com/ipfs/js-ipfs/issues/2089)) ([e7d6d3a](https://github.com/ipfs/js-ipfs/commit/e7d6d3a8462e9692530bcd037a4dcd7a236eeae2))
